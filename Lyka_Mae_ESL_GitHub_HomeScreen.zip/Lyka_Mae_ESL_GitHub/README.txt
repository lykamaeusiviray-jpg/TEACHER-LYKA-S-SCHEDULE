TEACHER LYKA ESL DASHBOARD — GitHub Pages / iPad Home Screen

1. Upload every file and the icons folder to your GitHub repository.
2. Make sure index.html is in the repository root.
3. In GitHub: Settings > Pages > Deploy from branch > main > /(root) > Save.
4. Open the published GitHub Pages link in Safari on iPad/iPhone.
5. Tap Share > Add to Home Screen > Add.

The dashboard is set up as a simple installable web app. It keeps schedule and price data in the browser's localStorage on that device/browser.
